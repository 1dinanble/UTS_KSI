<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <h3 class="h5 mb-4 text-gray-800">Menampilkan data users :</h3>

    <?php
    $queryTampil_dshbrd = "SELECT * FROM user WHERE role_id = 2 ";
    $subTampil = $this->db->query($queryTampil_dshbrd)->result_array();

    ?>

    <?php foreach ($subTampil as $tm) : ?>
        <div class="card mb-3" style="max-width: 540px;">
            <div class="row no-gutters">
                <div class="col-md-4">
                    <img src="<?= base_url('assets/img/profile/') . $tm['image']; ?>">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <h5 class="card-title"><?= $tm['name']; ?></h5>
                        <p class="card-text"><?= $tm['email']; ?></p>
                        <p class="card-text"><small class="text-muted">Bergabung sejak <?= date('d F Y', $tm['date_created']); ?></small></p>
                    </div>
                </div>
            </div>
        </div>

    <?php endforeach; ?>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->