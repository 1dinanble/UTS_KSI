<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <table class="table table-dark">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Senin</th>
                <th scope="col">Selasa</th>
                <th scope="col">Rabu</th>
                <th scope="col">Kamis</th>
                <th scope="col">Jumat</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th scope="row">1</th>
                <td>Matematika</td>
                <td>PKN</td>
                <td>Bahasa Indonesia</td>
                <td>Biologi</td>
                <td>Seni Budaya</td>
            </tr>
            <tr>
                <th scope="row">2</th>
                <td>Bahasa Inggris</td>
                <td>Kimia</td>
                <td>Fisika</td>
                <td>PAI</td>
                <td>Bahasa Jerman</td>
            </tr>
            <tr>
                <th scope="row">3</th>
                <td>Matematika Minat</td>
                <td>Bahasa Indonesia</td>
                <td>Kimia</td>
                <td>PKN</td>
                <td>Olahraga</td>
            </tr>
            <tr>
                <th scope="row">4</th>
                <td>Bahasa Inggris</td>
                <td>PAI</td>
                <td>Biologi</td>
                <td>Fisika</td>
                <td>Matematika Minat</td>
            </tr>
        </tbody>
    </table>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->